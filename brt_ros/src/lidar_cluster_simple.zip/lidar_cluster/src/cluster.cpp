#include <cluster.h>
using namespace autoware_msgs;
Cluster::Cluster(ros::NodeHandle &nh) : nh_(nh)
{

    init();
}
//  Cluster::~Cluster(){

//  }
void Cluster::cityBlock(ProcessPointClouds<pcl::PointXYZI> *PointProcessorI, const pcl::PointCloud<pcl::PointXYZI>::Ptr &inputCloud)
{

    float setLeafSize = 0.3;

    Eigen::Vector4f minpoint = Eigen::Vector4f(-10, -5, -2, 1);
    Eigen::Vector4f maxpoint = Eigen::Vector4f(30, 6, 0.5, 1);
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloudFiltered = PointProcessorI->FilterCloud(inputCloud, setLeafSize, minpoint, maxpoint);

    std::pair<pcl::PointCloud<pcl::PointXYZI>::Ptr, pcl::PointCloud<pcl::PointXYZI>::Ptr> segmentCloud = PointProcessorI->SegmentPlane(cloudFiltered, 50, 0.3);

    // clustering
    std::vector<pcl::PointCloud<pcl::PointXYZI>::Ptr> cloudClusters = PointProcessorI->Clustering(segmentCloud.first, 0.53, 10, 500);

    int clusterId = 0;

    for (pcl::PointCloud<pcl::PointXYZI>::Ptr cluster : cloudClusters)
    {
        std::cout << "cluster size ";
        PointProcessorI->numPoints(cluster);
        // renderPointCloud(viewer,cluster,"obstCloud"+std::to_string(clusterId),colors[clusterId]);
        std::cout << "ClusterId: " << clusterId << std::endl;
        // render box;
        Box box = PointProcessorI->BoundingBox(cluster);
        ++clusterId;
        std::cout << "box: " << box.x_min << box.x_max << std::endl;
    }
}

void Cluster::init()
{
    this->pointProcessorI = new ProcessPointClouds<pcl::PointXYZI>();
    pointcloud_topic = "/rslidar_points";
    pubClouds = nh_.advertise<sensor_msgs::PointCloud2>("points2_convert", 1);
    pubClouds1 = nh_.advertise<sensor_msgs::PointCloud2>("points1_convert", 1);
    pubCloudsmsg = nh_.advertise<DetectedObjectArray>("/detection/lidar_detector/objects", 1);
    subclidar = nh_.subscribe(pointcloud_topic, 10, &Cluster::callback, this);

    nh_.param<float>("/lidar_cluster_node/min_x", min_x, -2);
    nh_.param<float>("/lidar_cluster_node/min_y", min_y, -2);
    nh_.param<float>("/lidar_cluster_node/min_z", min_z, -2);
    nh_.param<float>("/lidar_cluster_node/max_x", max_x, 20);
    nh_.param<float>("/lidar_cluster_node/max_y", max_y, 20);
    nh_.param<float>("/lidar_cluster_node/max_z", max_z, 20);
    cout << "min_x:" << min_x << endl;
    cout << "min_y:" << min_y << endl;
    cout << "min_z:" << min_z << endl;
    cout << "max_x:" << max_x << endl;
    cout << "max_y:" << max_y << endl;
    cout << "max_z:" << max_z << endl;
    nh_.param<float>("/lidar_cluster_node/distanceThreshold", distanceThreshold, 0.5);
    cout << "distanceThreshold:" << distanceThreshold << endl;
}
void Cluster::callback(const sensor_msgs::PointCloud2ConstPtr &cloud)
{
    pcl::PointCloud<pcl::PointXYZI>::Ptr temp_cloud(new pcl::PointCloud<pcl::PointXYZI>);
    pcl::fromROSMsg(*cloud, *temp_cloud);

    // do stuff
    // ROS_INFO("received %ld points", temp_cloud->points.size());

    // cityBlock(pointProcessorI, temp_cloud);
    float setLeafSize = 0.3;

    Eigen::Vector4f minpoint = Eigen::Vector4f(min_x, min_y, min_z, 1);
    Eigen::Vector4f maxpoint = Eigen::Vector4f(max_x, max_y, max_z, 1);
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloudFiltered = this->pointProcessorI->FilterCloud(temp_cloud, setLeafSize, minpoint, maxpoint);
    std::pair<pcl::PointCloud<pcl::PointXYZI>::Ptr,
              pcl::PointCloud<pcl::PointXYZI>::Ptr>
        segmentCloud = this->pointProcessorI->SegmentPlane(cloudFiltered, 50, distanceThreshold);

    // clustering
    std::vector<pcl::PointCloud<pcl::PointXYZI>::Ptr> cloudClusters = pointProcessorI->Clustering(segmentCloud.first, 0.53, 10, 500);
    pcl::PointCloud<pcl::PointXYZI>::Ptr clusters((new pcl::PointCloud<pcl::PointXYZI>));
    DetectedObjectArray objarr;
    DetectedObject obj;
    objarr.header=cloud->header;
    for (pcl::PointCloud<pcl::PointXYZI>::Ptr cluster : cloudClusters)
    {
        sensor_msgs::PointCloud2 out;
        pcl::toROSMsg(*cluster, out);
        obj.pointcloud = out;
        *clusters += *cluster;
        std::cout << "cluster size ";
        pointProcessorI->numPoints(cluster);
        objarr.objects.push_back(obj);
    }
    sensor_msgs::PointCloud2 output;  // 创建一个消息对象 output
    sensor_msgs::PointCloud2 output1; // 创建一个消息对象 output

    // 转换成ROS信息
    pcl::toROSMsg(*segmentCloud.first, output1);
    pcl::toROSMsg(*clusters, output);
    output.header.frame_id = "rslidar";
    pubClouds1.publish(output1);
    pubClouds.publish(output);
    pubCloudsmsg.publish(objarr);
}
