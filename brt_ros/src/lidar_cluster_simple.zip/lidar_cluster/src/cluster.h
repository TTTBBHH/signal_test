#pragma once
#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_types.h>
#include "processPointClouds.cpp"
#include <autoware_msgs/DetectedObjectArray.h>
// #include "../src/render/render.h"
using namespace std;
class Cluster
{

private:
    ros::NodeHandle nh_;
    ros::Publisher pubClouds;
    ros::Publisher pubClouds1;
    ros::Publisher pubCloudsmsg;
    ros::Subscriber subclidar;
    string pointcloud_topic;

    ProcessPointClouds<pcl::PointXYZI> *pointProcessorI ;
float min_x=0;
float min_y=0;
float min_z=0;
float max_x=0;
float max_y=0;
float max_z=0;
float distanceThreshold=0.3;

    void init();
    void callback(const sensor_msgs::PointCloud2ConstPtr &cloud);
    void cityBlock(ProcessPointClouds<pcl::PointXYZI>* PointProcessorI, const pcl::PointCloud<pcl::PointXYZI>::Ptr& inputCloud);

public:
    Cluster(ros::NodeHandle &nh) ;
        // ~Cluster();
};