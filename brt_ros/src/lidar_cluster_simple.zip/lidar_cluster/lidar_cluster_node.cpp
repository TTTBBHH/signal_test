#include <ros/ros.h>
#include <iostream>
#include <opencv2/opencv.hpp>
#include <yaml-cpp/yaml.h>
#include "src/cluster.h"
using namespace std;
using namespace cv;
int main(int argc, char **argv)
{
    ros::init(argc, argv, "lidar_cluster");
    ros::NodeHandle nh;
    ros::NodeHandle private_nh("~");
    Cluster cluster(nh);
        ROS_INFO("main: going into spin; let the callbacks do all the work");
    ros::spin();
    
    cv::Size image_size_;
    cv::Mat camera_instrinsics_;
    cv::Mat distortion_coefficients_;
    cv::Mat CameraExtrinsicMat_;

    std::string config_file_Camera_path = "/home/cqjtu/Documents/catktin_ros/src/cfg/lidar_camera_calibration64.yaml";
    cout << config_file_Camera_path << endl;

    cv::FileStorage config_camera(config_file_Camera_path, cv::FileStorage::READ);

    config_camera["CameraMat"] >> camera_instrinsics_;
    config_camera["DistCoeff"] >> distortion_coefficients_;
    config_camera["CameraExtrinsicMat"] >> CameraExtrinsicMat_;

    cout << "name:" << camera_instrinsics_<< endl;
    cout << "sex:" << distortion_coefficients_<< endl;
    cout << "age:" << CameraExtrinsicMat_ << endl;
    ROS_INFO("OK!");
    return 0;
}